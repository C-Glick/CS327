#include "JellyCandy.h"
//everything defined in the JellyCandy.h file 
//or in parent .cpp and .h files