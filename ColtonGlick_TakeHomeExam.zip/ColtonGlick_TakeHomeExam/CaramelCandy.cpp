#include "CaramelCandy.h"
//everything defined in the CaramelCandy.h file 
//or in parent .cpp or .h files