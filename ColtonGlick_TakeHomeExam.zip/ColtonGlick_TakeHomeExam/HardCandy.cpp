#include "HardCandy.h"
//everything defined in the HardCandy.h file
//or in parent .cpp and .h files