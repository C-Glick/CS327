#include "ChocolateCandy.h"
//everything defined in the ChocolateCandy.h file 
//or in parent .cpp or .h files